#!/bin/bash
"$JAVA_HOME"/bin/java -jar dss-app.jar
